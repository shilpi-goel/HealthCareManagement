﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using HealthCareManagement.Models;

namespace HealthCareManagement.Controllers
{
    public class PatientConsultationsController : Controller
    {
        private readonly HealthCareManagementContext _context;

        public PatientConsultationsController(HealthCareManagementContext context)
        {
            _context = context;
        }

        // GET: PatientConsultations
        public async Task<IActionResult> Index()
        {
            return View(await _context.PatientConsultation.ToListAsync());
        }

        // GET: PatientConsultations/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var patientConsultation = await _context.PatientConsultation
                .FirstOrDefaultAsync(m => m.ConsulatationId == id);
            if (patientConsultation == null)
            {
                return NotFound();
            }

            return View(patientConsultation);
        }

        // GET: PatientConsultations/Create
        public IActionResult Create(int patientId)
        {
            var patient = _context.Patient
                .FirstOrDefault(m => m.Id == patientId);
            if (patient == null)
            {
                return NotFound();
            }


            PatientConsultation consultation = new PatientConsultation();
            consultation.Patient = patient;

            return View(consultation);
        }

        // POST: PatientConsultations/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(PatientConsultation patientConsultation)
        {
            //if (ModelState.IsValid)
            {
                var patient = _context.Patient
                  .FirstOrDefault(m => m.Id == patientConsultation.Patient.Id);
                if (patient == null)
                {
                    return NotFound();
                }

                patientConsultation.Patient = patient;
                
                patientConsultation.Created = DateTime.Now;
                _context.Add(patientConsultation);
                await _context.SaveChangesAsync();
                //return RedirectToAction(nameof(Index));
            }
            return RedirectToAction("Details","Patients",new { Id= patientConsultation.Patient.Id });
        }

        // GET: PatientConsultations/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var patientConsultation = await _context.PatientConsultation.FindAsync(id);
            if (patientConsultation == null)
            {
                return NotFound();
            }
            return View(patientConsultation);
        }

        // POST: PatientConsultations/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ConsulatationId,ConsultationDate,PresentSymtoms,AdviceGiven,Medication,Comments,Created")] PatientConsultation patientConsultation)
        {
            if (id != patientConsultation.ConsulatationId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(patientConsultation);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PatientConsultationExists(patientConsultation.ConsulatationId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction("Index", "Patients");
            }
            return View(patientConsultation);
        }

        // GET: PatientConsultations/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var patientConsultation = await _context.PatientConsultation
                .FirstOrDefaultAsync(m => m.ConsulatationId == id);
            if (patientConsultation == null)
            {
                return NotFound();
            }

            return View(patientConsultation);
        }

        // POST: PatientConsultations/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var patientConsultation = await _context.PatientConsultation.FindAsync(id);
            _context.PatientConsultation.Remove(patientConsultation);
            await _context.SaveChangesAsync();
            return RedirectToAction("Index", "Patients");
        }

        private bool PatientConsultationExists(int id)
        {
            return _context.PatientConsultation.Any(e => e.ConsulatationId == id);
        }
    }
}
