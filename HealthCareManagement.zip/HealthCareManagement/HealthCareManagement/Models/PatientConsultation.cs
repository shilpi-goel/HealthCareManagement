﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HealthCareManagement.Models
{
    public class PatientConsultation

    {
        [Key]
        public int ConsulatationId { get; set; }

        public Patient Patient { get; set; }



        [Column(TypeName = "datetime")]
        [Required]
        public DateTime ConsultationDate
        {
            get { return DateTime.Now; }
            set { value = DateTime.Now; }
        }

        [Column(TypeName = "nvarchar(1000)")]
        [Required]
        public string PresentSymtoms { get; set; }

        [Column(TypeName = "nvarchar(1000)")]       
        [Required]
        public string AdviceGiven { get; set; }

        [Column(TypeName = "nvarchar(250)")]

        public string Medication { get; set; }
        [Column(TypeName = "nvarchar(1000)")]

        public string Comments { get; set; }

        public DateTime Created { get; set; }
    }
}
