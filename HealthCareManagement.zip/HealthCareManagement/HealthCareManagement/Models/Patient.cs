﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HealthCareManagement.Models
{
    public class Patient

    {
        
        [Key]
        public int Id { get; set; }

        [Column(TypeName = "nvarchar(250)")]
        [Required]
        public string FirstName { get; set; }

        [Column(TypeName = "nvarchar(250)")]
        [Required]
        public string LastName { get; set; }

        [Display(Name = "Date of Birth")]
        [DataType(DataType.Date)]
        [Column(TypeName = "datetime")]
        [Required]
        public DateTime DateOfBirth { get; set; }


        [Column(TypeName = "nvarchar(250)")]
        [Required]
        public string Gender { get; set; }

        [Column(TypeName = "nvarchar(250)")]
        [Required]
        public string Address1 { get; set; }

        [Column(TypeName = "nvarchar(250)")]
        [Required]
        public string Address2 { get; set; }

        [Column(TypeName = "nvarchar(250)")]
        [Required]
        public string City { get; set; }

        [Column(TypeName = "nvarchar(250)")]
        [Required]
        public string Postcode { get; set; }

        public DateTime Created { get; set; }
        public ICollection<PatientConsultation> PatientConsultations { get; set; }
    }
}
